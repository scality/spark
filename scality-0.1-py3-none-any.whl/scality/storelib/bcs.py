# -*- coding: utf-8 -*-
# pylint: disable=invalid-name
""" Parse/generate binary config-sections

"""

from __future__ import absolute_import
__all__ = ["GenerateSectionStart", "GenerateSectionEnd", "GenerateBranchStart", "GenerateBranchEnd", "GenerateInt", "GenerateString", "GenerateTimestamp", "GenerateRaw", "GenerateRawList", "ParseInt", "ParseString", "ParseTimestamp", "ParseRaw"]

import re
import six


def GenerateSectionStart(name):
    name = six.ensure_binary(name)
    data = b"S%.4d%s\n" % (len(name), name)
    return data


def GenerateSectionEnd():
    return b"s\n"


def GenerateBranchStart(name):
    name = six.ensure_binary(name)
    data = b"B%.4d%s\n" % (len(name), name)
    return data


def GenerateBranchEnd():
    return b"b\n"


def GenerateInt(name, val):
    name = six.ensure_binary(name)
    data = b"V%.4d%sI%i\n" % (len(name), name, val)
    return data


def GenerateString(name, val):
    name = six.ensure_binary(name)
    val = six.ensure_binary(val)
    data = b"V%.4d%sT%.12d%s\n" % (len(name), name, len(val), val)
    return data


def GenerateTimestamp(name, val):
    name = six.ensure_binary(name)
    data = b"V%.4d%sS%i\n" % (len(name), name, val)
    return data


def GenerateRaw(name, val):
    name = six.ensure_binary(name)
    if isinstance(val, str):
        val = six.ensure_binary(val)
    data = b"V%.4d%sR%.12d" % (len(name), name, len(val))
    if isinstance(val, bytes):
        data += val
    else:
        """ Iterate other val """
        for d in val:
            data += d
    data += b"\n"
    return data


def GenerateRawList(name, val):
    name = six.ensure_binary(name)
    data = [b"V%.4d%sR%.12d" % (len(name), name, len(val))]
    data.append(val)
    data.append(b"\n")
    return data


def GenerateAttrInt(name, val):
    name = six.ensure_binary(name)
    data = b"A%.4d%sI%i\n" % (len(name), name, val)
    return data


def GenerateAttrString(name, val):
    name = six.ensure_binary(name)
    val = six.ensure_binary(val)
    data = b"A%.4d%sT%.12d%s\n" % (len(name), name, len(val), val)
    return data


def ParseInt(response, name, default=None):
    """ return the value of the field with the provided name.
    If not found, return default """
    name = six.ensure_binary(name)
    p = re.compile(rb"^V%.4d%sI([0-9]+)$" % (len(name), name),
                   re.MULTILINE)
    res = p.search(response)
    if res:
        return int(res.group(1))
    return default


def ParseString(response, name):
    name = six.ensure_binary(name)
    p = re.compile(rb"^V%.4d%sT[0-9]{12}(.*)$" % (len(name), name),
                   re.MULTILINE)
    res = p.search(response)
    if res:
        return res.group(1)
    return None


def ParseTimestamp(response, name):
    name = six.ensure_binary(name)
    p = re.compile(rb"^V%.4d%sS([0-9]+)$" % (len(name), name),
                   re.MULTILINE)
    res = p.search(response)
    if res:
        return int(res.group(1))
    return None


def ParseRaw(response, name):
    name = six.ensure_binary(name)
    p = re.compile(rb"^V%.4d%sR([0-9]{12})" % (len(name), name),
                   re.MULTILINE)
    res = p.search(response)
    if not res:
        return None
    size = res.group(1)
    return response[res.end():res.end()+int(size)]
