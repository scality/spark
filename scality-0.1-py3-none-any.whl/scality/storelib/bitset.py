# -*- coding: utf-8 -*-


from __future__ import division
import six
from six.moves import range


class BitSet(object):
    def __init__(self):
        self.value = 0

    def bit_set(self, pos):
        self.value |= (1 << pos)

    def set_from_val(self, val, numbits, pos):
        for b in range(numbits):
            if val & (1 << b):
                self.bit_set(pos + b)
            else:
                self.bit_clear(pos + b)

    def set_from_binstr(self, binstr, numbits, pos):
        val = 0
        for i, c in enumerate(binstr):
            try:
                val |= ord(c) << (i * 8)
            except TypeError:
                val |= c << (i * 8)
        self.set_from_val(val, numbits, pos)

    def bit_clear(self, pos):
        self.value &= ~(1 << pos)

    def to_bin(self, numbits):
        return six.ensure_binary(
            "".join(chr(a) for a in [((self.value>>c) & 0x0ff) for c in range(0,numbits,8)]),
            encoding='iso8859-1')

    def to_long(self):
        return self.value
