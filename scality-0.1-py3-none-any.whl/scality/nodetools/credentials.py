from __future__ import absolute_import
import json


def get_credentials(section, auth_file):
    """ Return a tuple containing username and password """
    username = None
    password = None
    credentials = {}

    try:
        credentials = json.load(open(auth_file))
    except IOError as err:
        raise Exception('Error while processing %s : %s\n'
                        'check it or SCALITY_AUTH_FILE env variable.'
                        '\n' % (auth_file, err.strerror))
    except Exception:
        raise Exception('Error while processing %s : Invalid json format?' % auth_file)
    try:
        username = credentials[section]['username']
        password = credentials[section]['password']
    except Exception:
        raise Exception("Could not retrieve credentials from '%s' section" % section)
    return (username, password)
