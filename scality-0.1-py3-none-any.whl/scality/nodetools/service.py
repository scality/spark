from __future__ import absolute_import
import os
import subprocess


def service_action(service_name, action):
    init_path = "/etc/init.d/%s" % service_name
    if os.path.isfile(init_path):
        subprocess.call([init_path, action])
    else:
        if service_name == "scality-node":
            subprocess.call(["systemctl", action, "scality-iod.service"])
            subprocess.call(["systemctl", action, "scality-node.service"])
        else:
            subprocess.call([
                "systemctl", action, "%s.service" % service_name
            ])


class NodeRestarter(object):
    """Context manager to handle scality-node stop then start."""
    def __init__(self, stop, force_start=False):
        """`NodeRestarter` constructor.

        If stop is specified stop the service and restarts it upon exit.
        If force_start, always start the service upon exit.
        """
        self._try_stop = stop
        self._should_restart = force_start

    @staticmethod
    def try_stop(pidof_args, sname):
        should_restart = False
        if not subprocess.call(['pidof'] + pidof_args):
            should_restart = True
            service_name = "scality-%s" % sname
            service_action(service_name, "stop")
        return should_restart

    def __enter__(self):
        if self._try_stop and self.try_stop(['bizstorenode'], 'node'):
            self._should_restart = True
        return self

    def __exit__(self, type_, value, traceback):
        if self._should_restart:
            service_action("scality-node", "start")
