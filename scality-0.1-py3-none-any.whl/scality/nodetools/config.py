# -*- coding: utf-8 -*-
'''
scality node configuration functions.
'''
from __future__ import print_function
from __future__ import absolute_import
import errno
import os
import re
import shutil
import pwd
import grp
from six.moves.configparser import ConfigParser     # pylint: disable=import-error
from glob import glob
from subprocess import call
from tempfile import mkdtemp

from scality.nodetools import (
    _FakeSecHead,
    is_ok_for_biziod,
    create_unix_like_account,
    DEFAULT_NB_VALUE,
    DEFAULT_NBA_VALUE
)
from scality.nodetools.node import NvpAllocator
from scality.nodetools.xml_config import XmlCfgEditor
import six


NODECFG_REGEXP = re.compile('(scality-node(|-[0-9]+)$)')
NODELINK_REGEXP = re.compile('(bizstorenode_[0-9]+$)')
SAMPLE_CONF = '/usr/share/scality-node/sample-conf/etc/scality/node'


DEFAULT_MSGSTORENODECFG_CONTENT = """\
<?xml version="1.0" encoding="UTF-8"?>
<section>
  <name>msgstorenodecfg</name>
  <version>2</version>
  <branch>
    <name>node</name>
    <val>
      <name>ip</name>
      <text></text>
    </val>
    <val>
      <name>port</name>
      <int></int>
    </val>
  </branch>
</section>
"""

__dirpath__ = os.path.dirname(__file__)


def chown_scality(path):
    """ Set ownership of 'path' to scality:scality
    """
    uid = pwd.getpwnam("scality").pw_uid
    gid = grp.getgrnam("scality").gr_gid
    os.chown(path, uid, gid)


def backup_configuration(dst):
    """ Backup the configuration of the nodes to dst
    """

    tmpdir = mkdtemp()
    try:
        with open(os.devnull, 'w') as fnull:
            if call(['scality-backup',
                     '--package',
                     'scality-node',
                     '--package',
                     'scality-biziod',
                     '-b', tmpdir, ],
                    stdout=fnull) == 0:
                for archive in glob(os.path.join(tmpdir, 'archives', '*')):
                    target = os.path.join(dst, os.path.basename(archive))
                    # if a less than one minute old archive already exists
                    # (i.e. reconfigure/reset ran twice in the same minute)
                    # keep the older one with the actual configuration
                    if not os.path.exists(target):
                        shutil.move(archive, dst)
                print("Successfully backed up node configuration to", dst)
                return True
            else:
                return False
    finally:
        shutil.rmtree(tmpdir)


def reset_configuration():
    '''
    Wipe existing configuration files.
    '''
    for dname in os.listdir('/etc'):
        matched = NODECFG_REGEXP.match(dname)
        # remove nodes configuration
        if matched:
            path = os.path.join('/etc', matched.group(1))
            realpath = os.path.realpath(path)
            # to support diskless configuration, wipe the real path
            # and keep the symlink that will point to the new conf
            shutil.rmtree(realpath)
        # remove biziod configuration
        if dname == 'biziod':
            realpath = os.path.realpath('/etc/scality/biziod')
            shutil.rmtree(realpath)
            os.mkdir(realpath)
            chown_scality(realpath)

        # remove obsolete symlinks
        matched = NODELINK_REGEXP.match(dname)
        if matched:
            path = os.path.join('/etc', matched.group(1))
            if os.path.islink(path):
                os.unlink(path)


def _generate_node_configuration(node, username, password):
    '''
    Create the configuration tree for a node.
    Args:
        node: a NodeAttributes tuple
        username: internal credentials
        password: internal credentials
    '''
    targetdir = '/etc/scality/node-{node.index}/'.format(node=node)
    # to support diskless configurations, use the real path
    targetdir = os.path.realpath(targetdir)
    if call(['rsync',
             '-a',
             '--ignore-existing',  # do not break things when reconfiguring
             os.path.join(SAMPLE_CONF, '.'), targetdir]) != 0:
        raise RuntimeError('failed to copy configuration for {0.name} '
                           'to /etc/scality/node-{0.index}/'.format(node))
    if call(['chown', '-R', 'scality:scality', targetdir]) != 0:
        raise RuntimeError('failed to change ownership of '
                           '/etc/scality/node-{0.index}/'.format(node))

    userdb = os.path.join(targetdir, 'userdb', 'localhost')
    create_unix_like_account(username, password, userdb)

    with XmlCfgEditor(node, 'config.xml') as cfg:
        cfg.replace_cfg_path()
        cfg.replace_log_path()

        cfg.set_value('config', 'ov_cluster_node',
                      'password', password)
        cfg.set_value('config', 'ov_cluster_node',
                      'portbind', node.mgmt_port)
        cfg.set_value('config', 'ov_interface_admin',
                      'portbind', node.admin_port)

        cfg.set_value('config', 'msgstore_protocol_chord',
                      'chordringport', node.chord_port,
                      ignore_missing=True)

    cfg = XmlCfgEditor(node, 'msgstorenodecfg.xml')
    if not cfg.exists():
        with cfg.open("w") as cfgfile:
            cfgfile.write(DEFAULT_MSGSTORENODECFG_CONTENT)

    with cfg:
        cfg.set_value('msgstorenodecfg', 'node',
                      'ip', node.chord_ip)
        cfg.set_value('msgstorenodecfg', 'node',
                      'port', node.chord_port, tag='int')

        cfg.set_bizionames()
    chown_scality(cfg.path())


def generate_nodes_configuration(parameters, username, password):
    '''
    Create the configuration tree for all nodes defined in parameters
    and save parameters to /etc/scality/node/nodes.conf.
    Args:
        parameters: a NodesParameters tuple
        username: internal credentials
        password: internal credentials
    '''
    for node in parameters.nodes:
        _generate_node_configuration(node, username, password)
    nodes_dir = os.path.join('/etc', 'scality', 'node')
    # to support diskless configurations, use the real path
    nodes_dir = os.path.realpath(nodes_dir)
    if not os.path.isdir(nodes_dir):
        os.makedirs(nodes_dir)
        chown_scality(nodes_dir)
    path = os.path.join(nodes_dir, 'nodes.conf')
    parameters.save(path)
    chown_scality(path)


def _upgrade_node_configuration(node):
    '''
    Update the configuration tree for a node.
    Exclude files and directories with configuration as they are
    updated by the node process itself.
    '''
    targetdir = '/etc/scality/node-{node.index}/'.format(node=node)
    # to support diskless configurations, use the real path
    targetdir = os.path.realpath(targetdir)
    filter_ = os.path.join(__dirpath__, 'upgrade.filter')
    if call(['rsync',
             '-a',
             '--delete',
             '--filter', 'merge {0}'.format(filter_),
             os.path.join(SAMPLE_CONF, '.'), targetdir]) != 0:
        raise RuntimeError('failed to upgrade configuration for {0.name} '
                           'to /etc/scality/node-{0.index}/'.format(node))
    if call(['chown', '-R', 'scality:scality', targetdir]) != 0:
        raise RuntimeError('failed to change ownership of '
                           '/etc/scality/node-{0.index}/'.format(node))


def upgrade_nodes_configuration(parameters):
    '''
    Update the configuration tree for all nodes defined in parameters.
    '''
    for node in parameters.nodes:
        _upgrade_node_configuration(node)


def _default_statcheck_start_time(disk_num):
    return disk_num * 1800


def _default_sweeper_start_time(disk_num):
    return disk_num * 3600


def _default_biziod_conf(disk_num):
    return {
        "ts": "00h-23h59m59s",
        "nba": DEFAULT_NBA_VALUE,
        "nb": DEFAULT_NB_VALUE,
        "reloc_verb": 1,
        "n_reloc": 50,
        "reloc_ratio_min": 10,
        "reloc_ratio_max": 60,
        "reloc_pass_time": 10,
        "reloc_manage_old_blobs_enable": 1,
        "reloc_manage_old_blobs_time": 240,
        "statcheck_start_time": _default_statcheck_start_time(disk_num),
        "sweeper_start_time": _default_statcheck_start_time(disk_num)
    }


def get_biziod_conf_files(disk_name):
    """Get all (main and store) biziod config for the given disk
    """

    # to support diskless configurations, use the real path
    biziod_path = os.path.realpath('/etc/scality/biziod')
    bizobj_path_prefix = os.path.join(biziod_path, 'bizobj.')

    # /etc/scality/biziod/bizobj.<disk_name>
    # always return it to make sure it is created with default value
    # if it does not exist yet
    bizobj_main_config = '{0}{1}'.format(bizobj_path_prefix, disk_name)

    # /etc/scality/biziod/bizobj.*.<disk_name>
    bizobj_store_configs = glob('{0}*.{1}'.format(bizobj_path_prefix, disk_name))

    return [bizobj_main_config] + bizobj_store_configs


def read_biziod_conf(config_path, disk_num):
    """Read and parse biziod config. If it does not exist, return
    a default biziod config
    """

    try:
        with open(config_path, 'r') as fileobj:
            parser = ConfigParser()
            parser.read_file(_FakeSecHead(fileobj))
            return dict(parser.items('scality'))
    except IOError as exc:
        if exc.errno == errno.ENOENT:
            return _default_biziod_conf(disk_num)
        raise


def save_biziod_conf(config_path, config):
    """Save biziod config into file
    """

    biziod_path = os.path.dirname(config_path)
    if not os.path.isdir(biziod_path):
        os.makedirs(biziod_path)
        chown_scality(biziod_path)

    with open(config_path, 'w') as fileobj:
        for key, value in six.iteritems(config):
            print(key, value, file=fileobj, sep='=')
    chown_scality(config_path)


def configure_nvp(config, nvp_base, disk_name, verbose):
    """
    Configure nvp if not already configured. Already configured nvp should
    never be changed.
    """

    nvp = '{0}/bizobj-{1}'.format(nvp_base, disk_name)
    if 'nvp' in config:
        if nvp != config['nvp']:
            print('nvp for {0} is already defined as {1}. '
                  'Suggested value for nvp would be {2}'.format(
                      disk_name,
                      config['nvp'],
                      nvp,
                  ))
    else:
        if is_ok_for_biziod(nvp_base):
            if not os.path.exists(nvp):
                if verbose:
                    print("Creating", nvp)
                os.mkdir(nvp)
                chown_scality(nvp)
            config['nvp'] = nvp
        else:
            if verbose:
                print(os.path.basename(nvp_base),
                      'is not mounted, bizobj.bin of',
                      disk_name,
                      'could not be store')


def generate_biziod_configuration(parameters, ignore_ssds=[], verbose=True):
    '''
    Generate (or update) biziod configuration files.
    '''
    # the type of disk is not readily available
    # we assume disks used in meta_disks are SSDs
    mountpoints = parameters.get_mountpoints()

    nvp_allocator = NvpAllocator(parameters, ignore_ssds=ignore_ssds)
    for disk_num, mountpoint in enumerate(mountpoints, start=1):
        disk_name = os.path.basename(mountpoint)
        nvp_base = nvp_allocator.get_nvp(mountpoint)
        nba = parameters.get_nba(mountpoint)
        nb = parameters.get_nb(mountpoint)

        for config_path in get_biziod_conf_files(disk_name):
            config = read_biziod_conf(config_path, disk_num)
            # reconfigure parameters that depend on the number of disks
            config['ts'] = parameters.generate_timeslots(disk_num)
            config['statcheck_start_time'] = _default_statcheck_start_time(disk_num)
            config['sweeper_start_time'] = _default_sweeper_start_time(disk_num)

            if nvp_base:
                configure_nvp(config, nvp_base, disk_name, verbose)
            if nba:
                config['nba'] = nba
            if nb:
                config['nb'] = nb

            save_biziod_conf(config_path, config)
