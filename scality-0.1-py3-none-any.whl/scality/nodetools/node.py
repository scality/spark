'''
Validate nodes configuration and provide high level properties.
'''
from __future__ import (
    absolute_import,
    print_function)
from __future__ import division
import sys
import six
from six.moves import range
from six.moves import zip

import logging
import os
import re
from schema import (
    Schema,
    SchemaError,
    SchemaUnexpectedTypeError,
    Optional,
    Or,
    Use,
    Regex
)
import socket
from collections import namedtuple
from six.moves.configparser import ConfigParser     # pylint: disable=import-error
from itertools import chain

try:
    import scaldisk.nodetools as nodetools
except ImportError:
    import scality.nodetools as nodetools

# Note: six.string_types does not work in schema objects...
if sys.version_info[0] == 3:
    stringtype = str
else:
    # Note: both flake8 and pylint comment on same line is not working in CI...
    stringtype = basestring     # noqa  # pylint: disable=undefined-variable

NodesParametersBase = namedtuple(
    'NodesParametersBase',
    ('name_prefix',
     'nb_nodes',
     'disk_mapping',
     'mount_prefix',
     'nb_disks',
     'meta_disks',
     'node_ip',
     'chord_ip',
     'use_ssl',
     'nba',
     'nb',
     )
)


STORED_OPTIONS = (
    'mnt_prefix',
    'disk_count',
    'process_count',
    'name_prefix',
    'node_ip',
    'chord_ip',
    'meta_disks',
    'disk_mapping',
    'use_ssl',
    'nba',
    'nb',
)

STORED_BOOL_OPTIONS = (
    'use_ssl',
)

NodeAttributes = namedtuple(
    'NodeAttributes',
    ('name',
     'index',
     'mgmt_port',
     'chord_ip',
     'chord_port',
     'admin_port',
     'disks',
     'use_ssl'))


RingNodeAttributes = namedtuple(
    'RingNodeAttributes',
    ('name',
     'index',
     'ring',
     'nid',
     'mgmt_port',
     'chord_port',
     'admin_port'))


logger = logging.getLogger(__name__)  # pylint: disable=C0103


BASE_MGMT_PORT = 8084
BASE_CHORD_PORT = 4244
BASE_ADMIN_PORT = 6444


MISSING_MOUNT = (
    "It seems that the following mountpoint is missing: {{0}}. "
    "It is not declared in fstab and does not contain a "
    "{0} file".format(nodetools.OK_FILE))


MISSING_MOUNTS = (
    "It seems that the following mountpoints are missing: {{0}}. "
    "They are not declared in fstab and do not contain a "
    "{0} file".format(nodetools.OK_FILE))


class Mountpoint:
    '''
    Status of a mountpoint:
    Declared: present in /etc/fstab (even if commented out or not mounted)
    Okayed: absent from /etc/fstab but directory exists with .ok_for_biziod
    Missing: absent from /etc/fstab and no .ok_for_biziod
    '''
    Declared, Okayed, Missing = list(range(3))


class CommaSeparatedList(object):  # pylint: disable=too-few-public-methods
    '''
    Comma separated list (as string) validator.
    '''

    def __init__(self, schema, error=None):
        self._schema = schema
        self._error = error

    def validate(self, data):
        '''
        Split data and validate elements.
        '''
        try:
            if isinstance(data, six.string_types):
                if len(data) == 0:
                    elts = []
                else:
                    elts = data.split(',')
            else:
                elts = [str(data), ]
            return Schema([self._schema, ], error=self._error).validate(elts)
        except (ValueError, AttributeError, TypeError):
            msg = '{0} must be a comma separated list of {1}'
            raise SchemaError(msg.format(data, self._schema))


def integer_pair(data):
    '''
    Colon separated integer pair validator.
    '''
    try:
        first, second = data.split(':')
        return (int(first), int(second))
    except (ValueError, AttributeError, TypeError):
        msg = '{0} must be an integer colon separated pair'
        raise SchemaUnexpectedTypeError(msg.format(data))


def ip_address(data, etype=SchemaUnexpectedTypeError):
    '''
    IPv4 address validator (the four numeric parts must be present).
    etype can be used to define the type of exception to raise on error.
    '''
    try:
        socket.inet_aton(data)
        if data.count('.') == 3 and not data.startswith('0.'):
            return data
    except socket.error:
        pass
    msg = '{0} must be an IPV4 address with four numeric parts'.format(data)
    raise etype(msg)


def pick_nb_groups(nb_disks):
    '''
    Choose a number of groups to schedule relocation.
    If the number of disks is a multiple of 2, 3, 4 or 6
    we choose the highest factor.
    If not, we choose the number of groups giving the highest
    remainder (i.e. lowest size difference between groups).
    '''
    highest_factor = -1
    with_lowest_diff = 1
    max_remainder = 0
    ratio = 0
    remainder = 0
    for nb_groups in [1, 2, 3, 4, 6]:
        ratio = nb_disks // nb_groups
        remainder = nb_disks % nb_groups
        if ratio == 0:
            # fewer disks than groups
            continue
        if remainder == 0:
            highest_factor = nb_groups
        if remainder > max_remainder:
            max_remainder = remainder
            with_lowest_diff = nb_groups
    if highest_factor > 1:
        return highest_factor
    else:
        return with_lowest_diff


def generate_timeslots(nb_disks, index, duration=2):
    '''
    Generate relocation time slots for one disk among nb_disks.
    '''
    nb_groups = pick_nb_groups(nb_disks)
    slots = 24 // (nb_groups * duration)
    if nb_groups == 1:
        return "00h-23h59m59s"
    group = (index - 1) % nb_groups
    ts = []
    for slot in range(slots):
        start = (group * duration) + (slot * (nb_groups * duration))
        end = start + duration
        if end == 24:
            ts.append("%02dh-23h59m59s" % start)
        else:
            ts.append("%02dh-%02dh" % (start, end))
    return ','.join(ts)


# using nodes.conf parameter names
NODE_PARAMETERS_SCHEMA = Schema({
    'name_prefix': CommaSeparatedList(stringtype),
    'process_count': CommaSeparatedList(Use(int)),
    'mnt_prefix': CommaSeparatedList(Regex(r'^(/\w*)*/\w*[a-zA-Z_-]$')),
    'disk_count': CommaSeparatedList(Use(int)),
    Optional('meta_disks'): CommaSeparatedList(stringtype),
    Optional('disk_mapping'): CommaSeparatedList(Use(integer_pair)),
    'node_ip': Or('', Use(ip_address)),
    'chord_ip': Or('0.0.0.0', Use(ip_address)),
    Optional('rings'): CommaSeparatedList(stringtype),
    Optional('tier2_enabled'): Use(int),
    Optional('use_ssl', default=False): Use(bool),
    Optional('nba'): CommaSeparatedList(Use(int)),
    Optional('nb'): CommaSeparatedList(Use(int)),
}, ignore_extra_keys=True)


RING_NODES_SCHEMA = Schema(
    {'name_prefix': CommaSeparatedList(stringtype),
     'nb_nodes': CommaSeparatedList(Use(int)),
     'rings': CommaSeparatedList(stringtype)})


def _format_num(num, maxv):
    '''
    Format num with zero padding for a maximum value of maxv
    '''
    return str(num).zfill(len(str(maxv)))


class NodesParametersIndexError(Exception):
    '''
    Requesting a node or disk out of bounds.
    '''
    pass


class NodesParametersInvalidValue(Exception):
    '''
    Invalid node parameter.
    '''
    def __init__(self, msg, cause=None):
        if cause:
            msg = msg + ' because of ' + repr(cause)
        super(NodesParametersInvalidValue, self).__init__(msg)
        self.cause = cause


class FstabFile(object):
    '''
    Query mountpoints defined in fstab based on their prefix.
    This is necessary because the use of zero-padding is not specified
    in nodes.conf but deduced from the content of /etc/fstab.
    Commented out mountpoints are included.
    '''
    def __init__(self, fstab='/etc/fstab'):
        '''
        fstab can either be a file name or a file object.
        '''
        if isinstance(fstab, str):
            with open(fstab, 'r') as fstabfile:
                self._load(fstabfile)
        else:
            self._load(fstab)

    def _load(self, fileobj):
        self._lines = fileobj.readlines()

    def get_mountpoints(self, prefixes):
        """
        Get mountpoints matching one of the prefixes.
        Return a dict mapping (prefix, index) tuples to mountpoints,
        for example: {('/scality/disk', 1): '/scality/disk01', ...}
        """
        mountpoints = {}
        # Match a regular fstab line, commented or not
        # fetching the mount point if it matches mnt_prefix
        pattern = r'^(#.\s.)?\S+\s+(('
        pattern += r'|'.join(prefixes)
        # Note: the ending optional spaces (\s*) are to be lenient (see RING-18078)
        # freq and passno are optionals, defaulting to 0
        pattern += r')(\d+))\s+(\S+)\s+(\S+)(\s+(0|1))?(\s+(0|1|2))?\s*$'
        regex = re.compile(pattern)
        for line in self._lines:
            match = regex.match(line)
            if match and match.group(2) not in mountpoints:
                mountpoints[(match.group(3), int(match.group(4)))] = match.group(2)
        return mountpoints


class NodesParameters(NodesParametersBase, object):
    '''
    The set of parameters encoding the node and biziod layout on a server.
    Because the use of zero-padding is not specified but defined by the
    content of /etc/fstab (or the names of directories with .ok_for_biziod
    files), this class reads /etc/fstab at creation time to resolve disk names.
    fstab can be passed as a keyword argument for tests.
    '''

    # Note: this is a bad idea. Subclassing namedtuple cannot be done properly.
    def __new__(cls, **kwargs): # noqa: max-complexity: 13
        try:
            if 'fstab' in kwargs:
                fstab = kwargs.pop('fstab')
            elif os.path.isfile('/etc/fstab'):
                fstab = FstabFile('/etc/fstab')
            elif os.path.isfile('/proc/mounts'):
                fstab = FstabFile('/proc/mounts')
            else:
                logger.warning('Neither /etc/fstab nor /proc/mounts is present, empty mounts')
                fstab = FstabFile('/dev/null')
            parameters = NODE_PARAMETERS_SCHEMA.validate(kwargs)
            if parameters.pop('tier2_enabled', None):
                logger.warning('ignoring obsolete parameter tier2_enabled')

            # rename if necessary and convert to tuple
            parameters['nb_nodes'] = tuple(parameters.pop('process_count'))
            # RING-20593, allow a single name prefix with longer nb_nodes lists
            nb_nodes_len = len(parameters['nb_nodes'])
            if nb_nodes_len > 1 and len(parameters['name_prefix']) == 1:
                parameters['name_prefix'] = parameters['name_prefix'] * nb_nodes_len
            parameters['nb_disks'] = tuple(parameters.pop('disk_count'))
            parameters['mount_prefix'] = tuple(parameters.pop('mnt_prefix'))
            if 'nba' in parameters:
                parameters['nba'] = tuple(parameters.pop('nba'))
            else:
                parameters['nba'] = (str(nodetools.DEFAULT_NBA_VALUE), ) * len(parameters['nb_disks'])
            if 'nb' in parameters:
                parameters['nb'] = tuple(parameters.pop('nb'))
            else:
                parameters['nb'] = (str(nodetools.DEFAULT_NB_VALUE), ) * len(parameters['nb_disks'])
            NodesParameters._validate_lists(parameters)
            if 'meta_disks' in parameters:
                parameters['meta_disks'] = tuple(parameters.pop('meta_disks'))
                NodesParameters._validate_meta_disks(parameters)
            else:
                parameters['meta_disks'] = ('skip', ) * len(parameters['nb_disks'])
            if 'disk_mapping' in parameters:
                parameters['disk_mapping'] = tuple(parameters.pop('disk_mapping'))
                NodesParameters._validate_disk_mapping(parameters)
            else:
                groups = list(range(1, 1 + len(parameters['nb_nodes'])))
                parameters['disk_mapping'] = tuple(zip(groups, groups))
            self = super(NodesParameters, cls).__new__(cls, **parameters)
            self._assert_mountpoints(fstab)
            return self
        except SchemaError as exc:
            raise NodesParametersInvalidValue('invalid parameters', exc)

    @staticmethod
    def _validate_lists(parameters):
        '''
        Paired lists must have the same length.
        '''
        same_length = [
            ('nb_nodes', 'name_prefix'),
            ('nb_disks', 'mount_prefix')]
        if 'meta_disks' in parameters:
            same_length.append(('nb_disks', 'meta_disks'))
        if 'disk_mapping' in parameters:
            same_length.append(('nb_nodes', 'disk_mapping'))
        else:
            same_length.append(('nb_nodes', 'nb_disks'))
        msg = '{0} and {1} must have the same length ({2} != {3})'
        for tag1, tag2 in same_length:
            param1 = parameters[tag1]
            len1 = len(param1)
            param2 = parameters[tag2]
            len2 = len(param2)
            if len1 != len2:
                raise SchemaError(msg.format(tag1, tag2, len1, len2))

    @staticmethod
    def _validate_meta_disks(parameters):
        '''
        Metadata disks must be a mount prefix or skip.
        '''
        msg = '{1} is not a valid meta disk, possible values are: {0}'
        allowed_meta = set(parameters['mount_prefix'])
        allowed_meta.add('skip')
        for meta in parameters.get('meta_disks', ()):
            if meta not in allowed_meta:
                raise SchemaError(msg.format(', '.join(allowed_meta), meta), None)

    @staticmethod
    def _validate_disk_mapping(parameters):
        '''
        Disk mapping must be a surjection of node groups in disk groups.
        '''
        mapped_node_groups = [frm for frm, _ in parameters['disk_mapping']]
        ctr = nodetools._Counter()
        for frm in mapped_node_groups:
            ctr.count(frm)
        for node_group, count in ctr.items():
            msg = ('node group {0} is mapped to more than one disk group, '
                   'check disk_mapping')
            if count > 1:
                raise SchemaError(
                    msg.format(parameters['name_prefix'][node_group - 1]), None)
        for node_group, name_prefix in enumerate(parameters['name_prefix'], start=1):
            if node_group not in mapped_node_groups:
                msg = 'node group {0} is not mapped to a disk group, check disk_mapping'
                raise SchemaError(msg.format(name_prefix), None)
        for node_group, disk_group in parameters['disk_mapping']:
            if not 0 < disk_group <= len(parameters['nb_disks']):
                msg = ('disk group {1} mapped to node group {0} does not exist, '
                       'check disk_mapping')
                group_name = parameters['name_prefix'][node_group - 1]
                raise SchemaError(msg.format(group_name, disk_group), None)

    def _assert_mountpoints(self, fstab):
        '''
        Build a mapping from (prefix, index) tuples
        to (mountpoint, status) for all expected mountpoints,
        i.e. defined by mount_prefix and nb_disks,
        and a list of missing mountpoints.
        '''
        self._mountpoints = {}
        self._missing = []
        declared = fstab.get_mountpoints(self.mount_prefix)
        ctr = nodetools._Counter()
        for prefix, count in zip(self.mount_prefix, self.nb_disks):
            for num in range(count):
                index = ctr.count(prefix)
                key = (prefix, index)
                try:
                    self._mountpoints[key] = (declared[key], Mountpoint.Declared)
                except KeyError:
                    for pad in range(3):
                        mountpoint = '{0}{1:0{2}d}'.format(prefix, index, pad + 1)
                        if nodetools.is_ok_for_biziod(mountpoint):
                            self._mountpoints[key] = (mountpoint, Mountpoint.Okayed)
                            break
                    else:
                        mountpoint = '{0}{1}'.format(prefix, index)
                        self._mountpoints[key] = (mountpoint, Mountpoint.Missing)
                        self._missing.append(mountpoint)

    @staticmethod
    def parse_file(fileobj, filename=None, hasheader=True, fstab=None):
        '''
        Parse a configuration file, given as a file object,
        and return a NodesParameters instance.
        filename is for logging purposes only.
        '''
        section = 'scality'
        if not hasheader:
            fileobj = nodetools._FakeSecHead(fileobj)
        parser = ConfigParser()
        parser.read_file(fileobj)

        if parser.has_option(section, 'tier2_enabled'):
            logger.warning('Ignoring deprecated option tier2_enabled in %s', filename)
            parser.remove_option(section, 'tier2_enabled')
        # Remove unknown option
        for opt, _ in parser.items(section):
            if opt not in STORED_OPTIONS:
                logger.warning('Ignoring unknown option %s in %s', opt, filename)
                parser.remove_option(section, opt)
        options = dict(parser.items(section))
        for bool_option in STORED_BOOL_OPTIONS:
            if bool_option in options:
                options[bool_option] = parser.getboolean(section, bool_option)
        if fstab:
            options['fstab'] = fstab
        return NodesParameters(**options)

    @staticmethod
    def parse(filename):
        '''
        Parse a configuration file and return a NodesParameters instance.
        '''
        with open(filename, 'r') as config:
            return NodesParameters.parse_file(
                nodetools._FakeSecHead(config),
                filename=filename)

    def as_conf(self):
        '''
        Return parameters as a dictionary using nodes.conf key names and format.
        '''
        result = {}
        result['name_prefix'] = ','.join(self.name_prefix)
        process_count = [str(count) for count in self.nb_nodes]
        result['process_count'] = ','.join(process_count)
        result['mnt_prefix'] = ','.join(self.mount_prefix)
        disk_count = [str(count) for count in self.nb_disks]
        result['disk_count'] = ','.join(disk_count)
        disk_mapping = ['{0}:{1}'.format(nod, dsk) for nod, dsk in self.disk_mapping]
        result['disk_mapping'] = ','.join(disk_mapping)
        result['meta_disks'] = ','.join(self.meta_disks)
        result['node_ip'] = self.node_ip
        result['chord_ip'] = self.chord_ip
        result['use_ssl'] = self.use_ssl
        result['nba'] = ','.join([str(nba) for nba in self.nba])
        result['nb'] = ','.join([str(nb) for nb in self.nb])
        return result

    def save_file(self, fileobj):
        '''
        Save to a configuration file given as a writeable file object.
        '''
        for key, value in six.iteritems(self.as_conf()):
            if key == 'disk_mapping':
                # do not save disk_mapping if it is the default value
                if len(self.nb_nodes) == len(self.nb_disks):
                    groups = list(range(1, 1 + len(self.nb_nodes)))
                    if self.disk_mapping == tuple(zip(groups, groups)):
                        continue
            elif key in STORED_BOOL_OPTIONS:
                value = 'yes' if value else 'no'
            print(key, value, file=fileobj, sep='=')

    def save(self, filename):
        '''
        Save to a configuration file.
        Apply updates in passed dictionary if any.
        '''
        with open(filename, 'w') as out:
            self.save_file(out)

    def _disk_name(self, prefix, index):
        return os.path.basename(self._mountpoints[(prefix, index)][0])

    @property
    def disk_groups(self):
        '''
        Disk groups as a list of tuples of disk names.
        '''
        result = []
        ctr = nodetools._Counter()
        for prefix, count in zip(self.mount_prefix, self.nb_disks):
            result.append(tuple([self._disk_name(prefix, ctr.count(prefix))
                                 for _ in range(count)]))
        return result

    @property
    def mapped_disk_groups(self):
        '''
        Disk groups used by nodes as a list of tuples of disk names.
        '''
        disk_groups = self.disk_groups
        result = set()
        for _, mapped in self.disk_mapping:
            result.add(disk_groups[mapped - 1])
        return list(result)

    @property
    def nvp_only_disk_groups(self):
        '''
        Disk groups not used by nodes as a list of tuples of disk names.
        '''
        return [group
                for group in self.disk_groups
                if group not in self.mapped_disk_groups]

    def get_mountpoints(self, index=None, raise_exc=True, only_mapped=False):
        """
        Compute list of all mountpoints, according to nodes conf.
        If only_mapped is True, only return mountpoints where
        nodes store data, i.e. mountpoints for which a biziod
        instance must be running.
        """
        if raise_exc and self._missing:
            if len(self._missing) == 1:
                raise NodesParametersInvalidValue(
                    MISSING_MOUNT.format(self._missing[0]))
            else:
                raise NodesParametersInvalidValue(
                    MISSING_MOUNTS.format(', '.join(self._missing)))
        all_mapped = set([mapped for _, mapped in self.disk_mapping])
        ctr = nodetools._Counter()
        keys = [
            (prefix, ctr.count(prefix))
            for group, (prefix, count) in (
                enumerate(zip(self.mount_prefix, self.nb_disks), start=1))
            for _ in range(count)
            if group in all_mapped or not only_mapped]
        if index is None:
            return [self._mountpoints[key][0] for key in keys]
        else:
            try:
                key = keys[index - 1]
            except IndexError:
                raise NodesParametersIndexError(
                    'Mountpoint number {0} does not exist'.format(index))
            return [self._mountpoints[key][0], ]

    def mountpoints_with_prefix(self, prefix, raise_exc=True):
        """ Compute list of mountpoints with the given prefix """
        mountpoints = []
        for prefix_, count in zip(self.mount_prefix, self.nb_disks):
            for num in range(count):
                if prefix_ == prefix:
                    mountpoint, status = self._mountpoints[(prefix_, num + 1)]
                    if status != Mountpoint.Missing:
                        mountpoints.append(mountpoint)
        return mountpoints

    def get_disks(self, index=None, only_mapped=False):
        '''
        Return disk names.
        For the meaning of only_mapped, see get_mountpoints.
        '''
        mountpoints = self.get_mountpoints(index=index, only_mapped=only_mapped)
        return [os.path.basename(mntp) for mntp in mountpoints]

    @property
    def bizobj_on_ssd(self):
        '''
        Are bizobj.bin stored on SSD, i.e. is meta_disks used.
        '''
        return self.meta_disks.count('skip') != len(self.meta_disks)

    @property
    def nodes(self):
        '''
        Attributes of all the nodes of a server.
        '''
        ctr = nodetools._Counter()
        names = ['%s%s' % (prefix, _format_num(ctr.count(prefix), count))
                 for prefix, count in zip(self.name_prefix, self.nb_nodes)
                 for _ in range(1, count + 1)]
        mgmt_ports = [BASE_MGMT_PORT + n for n in range(sum(self.nb_nodes))]
        chord_ips = [self.chord_ip, ] * sum(self.nb_nodes)
        chord_ports = [BASE_CHORD_PORT + n for n in range(sum(self.nb_nodes))]
        admin_ports = [BASE_ADMIN_PORT + n for n in range(sum(self.nb_nodes))]
        disk_groups = self.disk_groups
        groups = chain.from_iterable(
            (disk_groups[index - 1], ) * nb
            for nb, (_, index) in zip(self.nb_nodes, self.disk_mapping))
        use_ssl = [self.use_ssl] * sum(self.nb_nodes)
        return [NodeAttributes._make(x)
                for x in zip(names,
                             list(range(1, len(names) + 1)),
                             mgmt_ports,
                             chord_ips,
                             chord_ports,
                             admin_ports,
                             groups,
                             use_ssl)]

    def get_nodes(self, index=None):
        '''
        Get one or all node names.
        Indices <= 0 are valid.
        '''
        if index is None:
            return [node.name for node in self.nodes]
        else:
            try:
                return self.nodes[index - 1].name
            except (TypeError, IndexError):
                raise NodesParametersIndexError('Node %s does not exist' % index)

    def generate_timeslots(self, index, duration=2):
        return generate_timeslots(sum(self.nb_disks), index, duration)

    # Disks (aka mountpoints) are formed as mount_prefixXX where XX is the disk number
    # e.g. mountpoint /scality/DATA/g1disk01 is formed from /scality/DATA/g1disk mount_prefix
    # nb and nba tuples are matching mount_prefix tuples
    # Finding a nb or nba value for a disk (mountpoint) is finding the nb/nba for the
    # corresponding mount_prefix
    def get_nb(self, mountpoint):
        ''' Get nb value matching a disk '''
        for prefix, nb in zip(self.mount_prefix, self.nb):
            if prefix in mountpoint:
                return nb
        return None

    def get_nba(self, mountpoint):
        ''' Get nba value matching a disk '''
        for prefix, nba in zip(self.mount_prefix, self.nba):
            if prefix in mountpoint:
                return nba
        return None


def ring_nodes(name_prefix, nb_nodes, rings, only_ring=None):
    '''
    Return named tuples for all nodes or nodes of the specified ring.
    '''
    params = RING_NODES_SCHEMA.validate(
        {
            'name_prefix': name_prefix,
            'nb_nodes': nb_nodes,
            'rings': rings
        })
    msg = '{0} and {1} must have the same length ({2} != {3})'
    name_prefix_l = len(params['name_prefix'])
    nb_nodes_l = len(params['nb_nodes'])
    rings_l = len(params['rings'])
    if name_prefix_l != nb_nodes_l:
        raise SchemaError(
            msg.format('name_prefix', 'nb_nodes', name_prefix_l, nb_nodes_l))
    if rings_l != nb_nodes_l:
        raise SchemaError(
            msg.format('rings', 'nb_nodes', rings_l, nb_nodes_l))
    ctr = nodetools._Counter()
    names = ['%s%s' % (prefix, _format_num(ctr.count(prefix), count))
             for prefix, count in zip(params['name_prefix'], params['nb_nodes'])
             for _ in range(1, count + 1)]
    mgmt_ports = [BASE_MGMT_PORT + n for n in range(sum(params['nb_nodes']))]
    chord_ports = [BASE_CHORD_PORT + n for n in range(sum(params['nb_nodes']))]
    admin_ports = [BASE_ADMIN_PORT + n for n in range(sum(params['nb_nodes']))]
    nids = [ctr.count(ring) - 1
            for ring, count in zip(params['rings'], params['nb_nodes'])
            for _ in range(count)]
    rings = [ring
             for ring, count in zip(params['rings'], params['nb_nodes'])
             for _ in range(count)]
    return [RingNodeAttributes._make(x)
            for x in zip(names,
                         list(range(1, len(names) + 1)),
                         rings,
                         nids,
                         mgmt_ports,
                         chord_ports,
                         admin_ports) if x[2] == only_ring or not only_ring]


class NvpAllocator(object):
    '''
    Allocate nvp to mountpoints based on the definition of meta_disks.
    '''
    def __init__(self, parameters, ignore_ssds=None):
        self._counter = nodetools._Counter()

        # identify nvp prefixes used in different groups
        # nvp_prefix_groups[nvp_prefix] will be the number of groups using this prefix
        nvp_prefix_groups = {}
        # current index related to a specific prefix
        nvp_prefix_index = {}
        for nvp_prefix in parameters.meta_disks:
            if nvp_prefix not in nvp_prefix_groups:
                nvp_prefix_groups[nvp_prefix] = 1
                nvp_prefix_index[nvp_prefix] = 0
            else:
                nvp_prefix_groups[nvp_prefix] += 1

        # map each mountpoint to the set of disks
        # that can be used to define its nvp
        # ticket RING-16501, quickfix for bizobj dispatch
        self._mapping = {}
        for bp_prefix, nvp_prefix in zip(parameters.mount_prefix, parameters.meta_disks):
            if nvp_prefix == 'skip':
                continue
            bps = parameters.mountpoints_with_prefix(bp_prefix)
            nvps = parameters.mountpoints_with_prefix(nvp_prefix)

            if ignore_ssds and isinstance(ignore_ssds, list):
                # Because of mountpoints with the same pattern than S3C disks,
                # some of them may be filtered
                nvps = [nvp for nvp in nvps if os.path.basename(nvp) not in ignore_ssds]

            sorted_nvps = sorted(nvps)

            # we make our best to have distinct sets of ssd disks for each groups
            # there will be some overlapping if (and only if) there are more groups than ssds
            sub_nvp = NvpAllocator.split_sublist(sorted_nvps, nvp_prefix_groups[nvp_prefix], nvp_prefix_index[nvp_prefix])
            nvp_prefix_index[nvp_prefix] += 1

            for bp in bps:
                self._mapping[bp] = tuple(sub_nvp)

    @staticmethod
    def split_sublist(alist, count, index):
        """Return the <index>th sublist resulting of the split of the list alist into count sub-lists
        sub-lists are guaranteed not to overlap if and only if the number of sub-lists is lower than
        the size of the list

        >>> [NvpAllocator.split_sublist([1], 2, i) for i in range(2)]
        [[1], [1]]

        >>> [NvpAllocator.split_sublist([1, 2], 1, i) for i in range(1)]
        [[1, 2]]

        >>> [NvpAllocator.split_sublist([1, 2], 2, i) for i in range(2)]
        [[1], [2]]

        >>> [NvpAllocator.split_sublist([1, 2, 3, 4], 2, i) for i in range(2)]
        [[1, 2], [3, 4]]

        >>> [NvpAllocator.split_sublist([1, 2, 3, 4], 3, i) for i in range(3)]
        [[1], [2], [3, 4]]

        >>> [NvpAllocator.split_sublist([1, 2, 3, 4], 4, i) for i in range(4)]
        [[1], [2], [3], [4]]

        >>> [NvpAllocator.split_sublist([1, 2, 3, 4], 6, i) for i in range(6)]
        [[1], [1], [2], [3], [3], [4]]

        >>> [NvpAllocator.split_sublist([1, 2, 3, 4], 8, i) for i in range(8)]
        [[1], [1], [2], [2], [3], [3], [4], [4]]

        >>> try:
        ...     NvpAllocator.split_sublist([], 2, 0)
        ... except AssertionError, e:
        ...     print(e)
        assert 0 != 0

        >>> try:
        ...     NvpAllocator.split_sublist([1], 2, 2)
        ... except AssertionError, e:
        ...     print(e)
        assert (2 >= 0 and 2 < 2)
        """
        list_size = len(alist)
        assert count > 0
        assert index >= 0 and index < count
        assert list_size != 0

        start = (list_size * index) // count
        end = (list_size * (index + 1)) // count
        if end == start:
            end += 1

        return alist[start:end]

    def get_nvp(self, mountpoint):
        try:
            nvp_set = self._mapping[mountpoint]
            return nvp_set[(self._counter.count(nvp_set) - 1) % len(nvp_set)]
        except KeyError:
            return None


def validate_default():
    '''
    Validate default configuration file.
    '''
    logger.addHandler(logging.StreamHandler())
    logger.setLevel(logging.INFO)
    try:
        parameters = NodesParameters.parse('/etc/scality/node/nodes.conf')
    except SchemaError as exc:
        logger.error('Invalid nodes.conf: %s', str(exc))
    else:
        from pprint import pformat
        logger.info(pformat(dict(parameters._asdict())))


if __name__ == '__main__':
    validate_default()
