'''
Helper classes to update the node and chord IP addresses.
'''
from __future__ import print_function

from __future__ import absolute_import
import os
import yaml

from scality.nodetools.node import NodesParameters
from scality.nodetools.xml_config import (
    XmlCfgReader,
    XmlCfgEditor)


class UpdateIpError(Exception):
    """
    Generic error for UpdateIp class
    """
    pass


class UpdateIp(object):

    def __init__(self, new_ip=None, ip_name=None):
        self.current_ip = None
        self.new_ip = new_ip
        self.ip_name = ip_name
        self.nodes = {}

        self._params = NodesParameters.parse('/etc/scality/node/nodes.conf')

        for node in self._params.get_nodes():
            self.nodes[node] = {ip_name: "undefined"}

    def ip_need_update(self):
        """
        Return true if IP need to be updated
        """
        return self.current_ip != self.new_ip

    def config_need_update(self):
        """
        Return True if configuration need to be updated
        """
        if self.ip_need_update():
            return True
        for key, value in self.nodes.items():
            if value[self.ip_name] != self.new_ip:
                return True
        return False

    def read_top_level_config(self):
        """
        Return the top level IP value
        """
        self.current_ip = getattr(self._params, self.ip_name)

    def update_top_level_config(self):
        """
        Write the top level IP value in nodes.conf
        """
        config = self._params.as_conf()
        config[self.ip_name] = self.new_ip
        NodesParameters(**config).save('/etc/scality/node/nodes.conf')

    def display_config(self, ip_name):
        """
        Print IP configuration:
         - Top level configuration (nodes.conf)
         - Per Node IP configuration (sagentd|msgstorenodecfg.xml) config
        """
        print(ip_name, "(Top level configuration):")

        if self.ip_need_update():
            print("\t", self.current_ip, "->", self.new_ip)
        else:
            print("\t", self.current_ip, "-> unchanged")

        print("%s (Per node configuration):" % ip_name)

        for node in self._params.nodes:
            print("Node", node.index, "(", node.name, "):")
            node_current_ip = self.nodes[node.name][self.ip_name]

            if node_current_ip != self.new_ip:
                print("\t", node_current_ip, "->", self.new_ip)
            else:
                print("\t", node_current_ip, "-> unchanged")


class UpdateNodeIp(UpdateIp):

    def __init__(self, new_ip=None, ip_name="node_ip"):
        super(UpdateNodeIp, self).__init__(new_ip, ip_name)
        self.read_top_level_config()
        self.read_per_node_config()

    def read_per_node_config(self, config_file="/etc/scality/sagentd.yaml"):
        """
        Parse sagentd config to find each node IP
        """
        if not os.path.exists(config_file):
            raise UpdateIpError("sagentd config not found")

        with open(config_file, 'r') as config:
            conf = yaml.load(config)

        if conf["daemons"]:
            for key, value in conf["daemons"].items():
                if value["type"] == "node":
                    # Unknow node, just ignore it
                    if key not in self._params.get_nodes():
                        continue
                    if value["address"] is not None:
                        self.nodes[key]["node_ip"] = value["address"]

    def update_per_node_config(self, config_file="/etc/scality/sagentd.yaml"):
        """
        Write New Node IP in sagentd config
        """
        if not os.path.exists(config_file):
            raise UpdateIpError("No existing sagentd config")

        with open(config_file, 'r') as config:
            conf = yaml.load(config)

        if conf["daemons"]:
            for key, value in conf["daemons"].items():
                if value["type"] == "node":
                    value["address"] = self.new_ip

        config_file_tmp = config_file + ".tmp"
        with open(config_file_tmp, "w") as config:
            yaml.dump(conf, config, default_flow_style=False)
        os.rename(config_file_tmp, config_file)


class UpdateChordIp(UpdateIp):

    def __init__(self, new_ip=None, ip_name="chord_ip"):
        super(UpdateChordIp, self).__init__(new_ip, ip_name)
        self.read_top_level_config()
        self.read_per_node_config()

    def read_per_node_config(self):
        for node in self._params.nodes:
            with XmlCfgReader(node, 'msgstorenodecfg.xml') as cfg:
                ip = cfg.get_value('msgstorenodecfg', 'node', 'ip')
                self.nodes[node.name][self.ip_name] = ip or 'undefined'

    def update_per_node_config(self):
        """
        Update Chord IP configuration:
         - Remove ifconfig.xml and iproute.xml.
         - Update Chord IP in msgstorenodecfg.xml
        """
        for node in self._params.nodes:
            config_dir = "/etc/scality/node-{node.index}".format(node=node)
            ifconfig = os.path.join(config_dir, 'ifconfig.xml')
            if os.path.exists(ifconfig):
                os.unlink(ifconfig)
            iproute = os.path.join(config_dir, 'iproute.xml')
            if os.path.exists(iproute):
                os.unlink(iproute)
            with XmlCfgEditor(node, 'msgstorenodecfg.xml') as cfg:
                cfg.set_value('msgstorenodecfg', 'node',
                              'ip', self.new_ip)
