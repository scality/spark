from __future__ import absolute_import
import os
import re

from lxml import etree


CFG_REGEXP = re.compile('^(/etc/scality/node)(?P<rest>/.*$|$)')
LOG_REGEXP = re.compile('^(/var/log/scality-node)(?P<rest>/.*$|$)')


class XmlCfgReader(object):
    """
    Helper class to access an XML configuration file
    under /etc/scality/node-<index>/confdb using lxml.
    """
    def __init__(self, node, *args):
        self._node = node
        nodedir = 'node-{node.index}'.format(node=node)
        self._filename = os.path.join('/etc', 'scality', nodedir, 'confdb', *args)
        self._doc = None

    def __enter__(self):
        parser = etree.XMLParser(remove_blank_text=True)
        self._doc = etree.parse(self._filename, parser)
        return self

    def __exit__(self, type_, value, traceback):
        self._doc = None

    def exists(self):
        return os.path.exists(self._filename)

    def open(self, *args, **kwargs):
        return open(self._filename, *args, **kwargs)

    def get_value(self, section, branch, val, tag='text'):
        """
        Set the value of a parameter in the edited file.
        """
        val = self._doc.xpath("/section[name[text()='{0}']]"
                              "/branch[name[text()='{1}']]"
                              "/val[name[text()='{2}']]"
                              "/{3}".format(section, branch, val, tag))
        try:
            return val[0].text
        except IndexError:
            return None

    def path(self):
        return self._filename


class XmlCfgEditor(XmlCfgReader):
    """
    Helper class to edit an XML configuration file
    under /etc/scality/node-<index>/confdb using lxml.
    """
    def __exit__(self, type_, value, traceback):
        if self._doc:
            with open(self._filename, 'wb') as out:
                self._doc.write(out, pretty_print=True)
                self._doc = None

    def set_value(self, section, branch, val, value, tag='text', ignore_missing=False):
        """
        Set the value of a parameter in the edited file.
        """
        val = self._doc.xpath("/section[name[text()='{0}']]"
                              "/branch[name[text()='{1}']]"
                              "/val[name[text()='{2}']]"
                              "/{3}".format(section, branch, val, tag))
        if not val:
            if not ignore_missing:
                raise ValueError("Node {0}::{1}::{2} not found".format(
                    section, branch, val
                ))
        else:
            val[0].text = str(value)

    def _replace_path(self, xpath, regexp, replace):
        for elt in self._doc.xpath(xpath):
            match = regexp.match(elt.text)
            if match:
                elt.text = replace.format(
                    node=self._node,
                    rest=match.group('rest'))

    def replace_cfg_path(self):
        """
        Replace all occurrences of /etc/scality/node
        with the path to this node's configuration directory.
        """
        return self._replace_path(
            "//text[starts-with(text(),'/etc/scality/node')]",
            CFG_REGEXP,
            '/etc/scality/node-{node.index}{rest}')

    def replace_log_path(self):
        """
        Replace all occurrences of /var/log/scality-node
        with the path to this node's log directory.
        """
        return self._replace_path(
            "//text[starts-with(text(),'/var/log/scality-node')]",
            LOG_REGEXP,
            '/var/log/scality-node-{node.index}{rest}')

    def set_bizionames(self):
        """Set the list of biziod names in msgstorenodecfg.xml."""
        node = self._doc.xpath("/section[name[text()='msgstorenodecfg']]"
                               "/branch[name[text()='node']]")
        names = node[0].xpath("branch[name[text()='bizionames']]")
        if names:
            names = names[0]
            etree.strip_elements(names, 'val')
        else:
            names = etree.SubElement(node[0], "branch")
            etree.SubElement(names, "name").text = "bizionames"
        for disk in self._node.disks:
            val = etree.SubElement(names, "val")
            etree.SubElement(val, "name").text = "bizioname"
            etree.SubElement(val, "text").text = disk
