'''
Utilities for setting up node/rest-connector.
'''
from __future__ import absolute_import
import logging
import os
import string
import random
import crypt
import six
from six.moves import range


logger = logging.getLogger(__name__)  # pylint: disable=C0103
OK_FILE = '.ok_for_biziod'
DEFAULT_NBA_VALUE = 8
DEFAULT_NB_VALUE = 4194319


def create_unix_like_account(user, password, dst, template='%s:%s:0:1:admin::\n'):
    '''
    Generate a file with the same structure as /etc/password.
    The following characters can be used for generate salt: [a-zA-Z0-9]
    '''
    valid_chars = string.ascii_letters + string.digits
    salt = "$6$" + "".join(random.choice(valid_chars) for _ in range(16)) + "$"

    if os.path.exists(dst) and os.path.getsize(dst) > 0:
        return

    try:
        dirpath = os.path.dirname(dst)
        if not os.path.isdir(dirpath):
            os.makedirs(dirpath)

        filedes = os.open(dst, os.O_RDWR | os.O_CREAT, 0o600)
        os.write(filedes, six.ensure_binary(template % (user, crypt.crypt(password, salt))))
        os.close(filedes)
    except Exception:
        logger.warning('Failed to update node configuration file %s', dst)
        raise


class _FakeSecHead(object):  # pylint: disable=too-few-public-methods
    """
    Fake a section header to be able to read nodes.conf with ConfigParser.

    Note: Since python3.2, ConfigParser.readfp() (which is deprecate btw)
          iterates on fp instead of calling fp.readline()
          so, make _FakeSecHead an iterator...
    """
    def __init__(self, fileobj):
        self.fileobj = fileobj
        self.sechead = '[scality]\n'

    def readline(self):
        '''
        Read a line.
        '''
        if self.sechead:
            try:
                return self.sechead
            finally:
                self.sechead = None
        else:
            return self.fileobj.readline()

    def __iter__(self):     # pylint: disable=non-iterator-returned
        return self

    def __next__(self):
        if self.sechead:
            try:
                return self.sechead
            finally:
                self.sechead = None
        else:
            for line in self.fileobj:
                return line
            raise StopIteration


class _Counter(object):
    '''
    Maintain counters by tag.
    '''
    def __init__(self):
        self._counters = {}

    def count(self, tag, inc=1):
        '''
        Increment the current counter for tag and return its value.
        '''
        index = self._counters.get(tag, 0)
        index = index + inc
        self._counters[tag] = index
        return index

    def get(self, tag):
        '''
        Return the current counter value for tag.
        '''
        return self._counters.get(tag, 0)

    def items(self):
        '''
        Return the counter items.
        '''
        return list(self._counters.items())


def is_ok_for_biziod(path):
    return os.path.ismount(path) or os.path.exists(os.path.join(path, OK_FILE))
