import copy
import elasticsearch6 as elasticsearch


BASE_TEMPLATE = {
    "settings": {
        "number_of_shards": 3,
        "number_of_replicas": 1
    },
    "aliases": {},
    "mappings": {
        "_default_": {
            "_all": {
                "enabled": "false"
            },
            "dynamic_templates": [{
                "timestamps_as_date": {
                    "match_pattern": "regex",
                    "path_match": ".*timestamp",
                    "mapping": {
                        "type": "date"
                    }
                }
            }, {
                "strings_not_analyzed": {
                    "match": "*",
                    "match_mapping_type": "string",
                    "mapping": {
                        "type": "keyword"
                    }
                }
            }]
        }
    }
}


def create_if_not_exists(
        conn: elasticsearch.Elasticsearch,
        index_name: str,
        aliases: 'typing.Optional[typing.Sequence[str]]'=None
) -> None:  # pragma: no cover
    """Set up index with dynamic mapping and aliases."""
    if conn.indices.exists(index_name):
        return

    template = copy.deepcopy(BASE_TEMPLATE)
    if aliases:
        template['aliases'] = {
            alias: {}
            for alias in aliases
        }
    conn.indices.create(
        index=index_name,
        body=template
    )
