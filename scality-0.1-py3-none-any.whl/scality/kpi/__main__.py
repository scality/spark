import argparse
import copy
import logging
import os
import sys

import yaml

from scality.kpi.capacity_planning import main as capacity_planning


DEFAULT_CONFIG = {
    'hosts': ['http://localhost/api/v0.1/es_proxy/'],
    'timeout': 240,
    'disk_stats_index': 'stats-disk',
    'disk_kpi_index': 'scality-kpi-capacity',
    'disk_planning_period': 30,
    'disk_stat_frequency': 150,
    'disk_planning_threshold': 0.8,
}


def parse_arguments(
        parameters: 'typing.Sequence[typing.Any]'
) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c", "--config", dest="config_filepath",
        default="/etc/scality/scality-kpi.yaml",
        help="Config filepath"
    )
    parser.add_argument(
        "-d", "--debug", action="store_true", default=False,
        help="Show debug logs"
    )

    subparsers = parser.add_subparsers(dest='command')
    subparsers.required = True

    capacity_parser = subparsers.add_parser('capacity')
    capacity_parser.set_defaults(func=capacity_planning.plan_capacity)

    return parser.parse_args(parameters)


def setup_logging(args: argparse.Namespace) -> None:
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )


def read_config_file(args: argparse.Namespace) -> dict:
    if not os.path.exists(args.config_filepath):
        logging.error("Config file not found: %s", args.config_filepath)
        raise SystemExit(1)

    with open(args.config_filepath) as config_file:
        config = yaml.load(config_file)

    return config


def main(parameters: 'typing.Optional[dict]'=None) -> int:
    args = parse_arguments(parameters or sys.argv[1:])
    setup_logging(args)
    config = copy.deepcopy(DEFAULT_CONFIG)
    config.update(read_config_file(args))
    config.update(vars(args))
    func = config.pop('func')

    return func(config)


if __name__ == '__main__':  # pragma: no cover
    sys.exit(main())
