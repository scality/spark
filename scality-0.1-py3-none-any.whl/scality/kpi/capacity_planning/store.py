import logging

import elasticsearch6 as elasticsearch

from scality.kpi import mapping


_logger = logging.getLogger(__name__)


def store_kpis(
        config: dict,
        conn: elasticsearch.Elasticsearch,
        kpis: 'typing.Iterator[dict]'
) -> int:
    """Store computed KPIs to appropriate ES index."""
    kpi_index = config['disk_kpi_index']
    mapping.create_if_not_exists(conn, kpi_index)
    actions = compute_actions_from_kpis(kpi_index, kpis)
    try:
        elasticsearch.helpers.bulk(
            client=conn,
            actions=actions,
            stats_only=True
        )
    except elasticsearch.ElasticsearchException as exc:
        _logger.critical(
            'Elasticsearch error while pushing KPIs: %s', str(exc)
        )
        return 3
    return 0


def compute_actions_from_kpis(
        index: str,
        kpis: 'typing.Iterator[dict]'
) -> 'typing.Iterator[dict]':
    """Generate ES actions.

    Can be consumed by ES bulk commands.
    """
    for kpi in kpis:
        yield {
            '_source': kpi,
            '_op_type': 'index',
            '_index': index,
            '_type': index,
        }
