import collections
import datetime

import elasticsearch6 as elasticsearch
import elasticsearch_dsl


METRICS = ['stored_space', 'used_space', 'avail_space', 'total_space']
SELECT_FIELDS = METRICS + ['ring']

# "640K ought to be enough for anybody" :P
MAX_NB_RINGS = 50
MAX_NB_SERVERS_PER_RING = 5000
MAX_NB_DISKS_PER_SERVER = 1000


def fetch_capacity_data(
        conn: elasticsearch.Elasticsearch,
        config: dict
) -> dict:
    """Find out old and current capacities.

    For each RING:

    Look for oldest document from this RING
    (with max: `config['disk_planning_period']` days).

    Then, for current and old date, look for disk data
    during these periods, within a distance of
    3*`config['disk_stat_frequency']` seconds.

    We need this interval to ignore disks that could have
    been added or removed during the period.

    Data is then summed per RING.

    :return: A dict containing, for each currently existing RING
            the date from which old data have been retrieved,
            along with the old and current capacities.
    """
    # 3*push frequency to be sure to have a complete dataset.
    search_window = 3 * config['disk_stat_frequency']
    search = elasticsearch_dsl.Search(
        using=conn,
        index=config['disk_stats_index']
    )

    current_capacities = fetch_current_capacities(
        search,
        search_interval=search_window
    )

    # Find date of oldest document per RING
    # Only check for RINGs which have a current value
    # in order to not consider deleted ones
    oldest_documents = find_oldest_document_date(
        search,
        starting_day=config['disk_planning_period'],
        rings=list(current_capacities.keys())
    )

    # Find capacity values at these old dates
    old_capacities = {
        ring: fetch_ring_capacities(search, ring, when, interval=search_window)
        for ring, when in oldest_documents.items()
    }

    capacities = {
        ring: {
            'reference_date': datetime.datetime.fromtimestamp(
                oldest_documents[ring] / 1000,
                tz=datetime.timezone.utc
            ),
            'old': old_capacities[ring],
            'current': capacities
        }
        for ring, capacities in current_capacities.items()
    }

    return capacities


def fetch_current_capacities(
        search: elasticsearch_dsl.Search,
        search_interval: int
) -> 'typing.Mapping[str, typing.Mapping[str, int]]':
    """Compute current capacities per RING."""
    es_period = 'now-{}s'.format(search_interval)
    search = search.filter(
        'range', **{'@timestamp': {'gt': es_period}}
    )[0:0]
    for field in SELECT_FIELDS:
        search = search.filter('exists', field=field)

    # Filter by disk, key being composite (ring, server, disk)
    search.aggs.bucket(
        'ring', 'terms', field='ring', size=MAX_NB_RINGS
    ).bucket(
        'host', 'terms', field='host', size=MAX_NB_SERVERS_PER_RING
    ).bucket(
        'diskname', 'terms', field='diskname', size=MAX_NB_DISKS_PER_SERVER
    ).bucket(
        'current', 'top_hits',
        sort={'@timestamp': 'desc'}, size=1,
        _source={'include': SELECT_FIELDS}
    )
    result = search.execute()
    capacities = collections.defaultdict(
        lambda: {metric: 0 for metric in METRICS}
    )
    for ring in result.aggregations.ring.buckets:
        for metric, value in host_sums_by_metric(ring.host.buckets).items():
            capacities[ring.key][metric] += value
    return capacities


def find_oldest_document_date(
        search: elasticsearch_dsl.Search,
        starting_day: int,
        rings: 'typing.Optional[typing.Sequence[str]]'=None,
) -> 'typing.Mapping[str, int]':
    """Find oldest document per RING for given range."""
    period_start = 'now-{}d'.format(starting_day)
    search = search.filter(
        'range', **{'@timestamp': {'gte': period_start}}
    ).filter(
        'exists', field='total_space'
    )[0:0]
    if rings:
        search = search.filter('terms', ring=rings)
    for field in SELECT_FIELDS:
        search = search.filter('exists', field=field)
    search.aggs.bucket(
        'ring', 'terms', field='ring'
    ).bucket(
        'oldest', 'top_hits', sort={'@timestamp': 'asc'}, size=1
    )
    result = search.execute()
    oldest = {
        ring.key: ring.oldest.hits.hits[0]['sort'][0]
        for ring in result.aggregations.ring.buckets
    }
    return oldest


def fetch_ring_capacities(
        search: elasticsearch_dsl.Search,
        ring: str,
        when: int,
        interval: int
) -> dict:
    """Find RING capacity at a given date."""
    search = search.filter('range', **{'@timestamp': {
        'gte': when,
        'lt': when + interval * 1000,
    }}).filter('terms', ring=[ring])[0:0]

    for field in METRICS:
        search = search.filter('exists', field=field)

    # Filter by disk, key being composite (server, disk) for a specified RING.
    search.aggs.bucket(
        'host', 'terms', field='host', size=MAX_NB_SERVERS_PER_RING
    ).bucket(
        'diskname', 'terms', field='diskname', size=MAX_NB_DISKS_PER_SERVER
    ).bucket(
        'current', 'top_hits',
        sort={'@timestamp': 'desc'}, size=1,
        _source={'include': SELECT_FIELDS}
    )

    result = search.execute()
    return host_sums_by_metric(result.aggregations.host.buckets)


def host_sums_by_metric(hosts):
    """Compute a sum over all hosts for each metric."""
    capacities = {metric: 0 for metric in METRICS}
    for host in hosts:
        for disk in host.diskname.buckets:
            entry = disk.current.hits.hits[0]['_source']
            for metric in METRICS:
                capacities[metric] += entry[metric]
    return capacities
