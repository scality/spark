import datetime


def compute_kpis(config: dict, capacities: dict) -> 'typing.Iterator[dict]':
    """Interpret RING disk usage.

    Given RING old and current disk usage, computes:

    * Disk usage growth
    * Days before reaching XX% disk usage
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    for ring, data in capacities.items():
        current = data['current']
        interval_days = (now - data['reference_date']).days
        threshold = config['disk_planning_threshold']
        entry = {
            '@timestamp': now.isoformat(),
            'reference_date': data['reference_date'].isoformat(),
            'ring': ring,
            'used_capacity_age': interval_days,
            'usage_growth': current['used_space'] - data['old']['used_space'],
            'daily_capacity_growth': None,
            'threshold': threshold,
            'days_before_threshold': None,
        }
        entry.update(current)
        for field, value in data['old'].items():
            entry['old_{}'.format(field)] = value
        if interval_days:
            entry['daily_capacity_growth'] = (
                entry['usage_growth'] / interval_days
            )
        if (entry['daily_capacity_growth'] or 0) > 0:
            required_empty_space = current['total_space'] * (1 - threshold)
            disk_space_to_threshold = (
                current['avail_space'] - required_empty_space
            )
            if disk_space_to_threshold <= 0:
                entry['days_before_threshold'] = 0
            elif entry['daily_capacity_growth']:
                entry['days_before_threshold'] = (
                    disk_space_to_threshold / entry['daily_capacity_growth']
                )
        yield entry
