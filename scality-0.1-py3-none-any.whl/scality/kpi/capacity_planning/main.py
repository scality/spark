import logging

import elasticsearch6 as elasticsearch

from scality.kpi.capacity_planning import compute
from scality.kpi.capacity_planning import fetch
from scality.kpi.capacity_planning import store

_logger = logging.getLogger(__name__)


def plan_capacity(config: dict) -> int:
    """Interpret RING disk usage evolution.

    Computes:

    * net available: available disk space considering storage overhead
    * disk usage growth over a period (e.g. 30 days)
    * days before XX% disk usage
    """
    if 'disk_search_interval' in config:
        _logger.warning('`disk_search_interval` parameter is deprecated: ' +
                        'use `disk_stat_frequency` instead')
    conn = elasticsearch.Elasticsearch(
        hosts=config['hosts'], timeout=config['timeout']
    )
    try:
        capacities = fetch.fetch_capacity_data(conn, config)
    except elasticsearch.exceptions.RequestError as request_error:
        if str(request_error) == (
                "RequestError(400, 'search_phase_execution_exception', "
                "'No mapping found for [@timestamp] in order to sort on')"
        ):
            _logger.critical('No data to work on, aborting')
            return 2
        raise
    kpis = compute.compute_kpis(config, capacities)
    return store.store_kpis(config, conn, kpis)
