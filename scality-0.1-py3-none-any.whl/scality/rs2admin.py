# -*- coding: utf-8 -*-
from __future__ import absolute_import
from hashlib import sha1
import hmac
import base64
import six
import six.moves.urllib.request     # pylint: disable=E0401
import six.moves.urllib.parse
import six.moves.urllib.error
import datetime
import time
import six.moves.http_client

contentmd5 = ""
contenttype = ""
httpdate = ""
hdrtosign = []
resource = ""

class RS2Admin(object):

    def __init__(self, url="http://localhost:8180", password=None):
        self.conn = six.moves.http_client.HTTPConnection(url)
        self.password = password

    def __encode(self, text, urlencode=False):
        try:
            b64encode =  base64.encodebytes
        except AttributeError:
            b64encode =  base64.encodestring

        b64_hmac = six.ensure_str(
            b64encode(
                hmac.new(
                    six.ensure_binary(self.password),
                    six.ensure_binary(text),
                    sha1).digest()
            )
        ).strip()

        if urlencode:
            return six.moves.urllib.parse.quote_plus(b64_hmac)
        else:
            return b64_hmac

    def list_bucket_user(self, user):

        resource = "/users/%s" % user

        httpdate = datetime.datetime.utcfromtimestamp(time.time()).strftime("%a, %d %b %Y %H:%M:%S +0000")
        headers = {"Date": httpdate}
        method = "GET"

        stringtosign = "%s\n%s\n%s\n%s\n%s%s" % (method, contentmd5, contenttype, httpdate, "\n".join(hdrtosign), resource)

        sig = self.__encode(stringtosign)
        # print "ToSign='%s'" % stringtosign

        headers["Authorization"] = "AWS none:" + sig

        self.conn.request(method, resource, None, headers)
        resp = self.conn.getresponse()

        if resp.status != 200:
            raise Exception(str(resp.status))
        res = resp.read()
        self.conn.close()
        return res

    def create_user(self, user, dname):

        resource = "/users/%s?dname=%s" % (user, dname)

        httpdate = datetime.datetime.utcfromtimestamp(time.time()).strftime("%a, %d %b %Y %H:%M:%S +0000")
        headers = {"Date": httpdate}
        method = "PUT"

        stringtosign = "%s\n%s\n%s\n%s\n%s%s" % (method, contentmd5, contenttype, httpdate, "\n".join(hdrtosign), resource)

        sig = self.__encode(stringtosign)
        # print "ToSign='%s'" % stringtosign

        headers["Authorization"] = "AWS none:" + sig
        headers["Content-Length"] = "0"

        self.conn.request(method, resource, None, headers)
        resp = self.conn.getresponse()

        if resp.status != 200:
            raise Exception(str(resp.status))
        res = resp.read()
        self.conn.close()
        return res

    def delete_user(self, user):

        resource = "/users/%s" % (user)

        httpdate = datetime.datetime.utcfromtimestamp(time.time()).strftime("%a, %d %b %Y %H:%M:%S +0000")
        headers = {"Date": httpdate}
        method = "DELETE"

        stringtosign = "%s\n%s\n%s\n%s\n%s%s" % (method, contentmd5, contenttype, httpdate, "\n".join(hdrtosign), resource)

        sig = self.__encode(stringtosign)
        # print "ToSign='%s'" % stringtosign

        headers["Authorization"] = "AWS none:" + sig

        self.conn.request(method, resource, None, headers)
        resp = self.conn.getresponse()

        if resp.status != 200:
            raise Exception(str(resp.status))
        res = resp.read()
        self.conn.close()
        return res
