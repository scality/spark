from __future__ import absolute_import
from scality.sprov.ring import Ring
from scality.sprov.component import Node, Server, DiskGroup, Site
from scality.sprov.cos import ClassOfService
from scality.sprov.event import FailureSet, FailureEventSet


def get_model_from_sup(supervisor, ring_name,
                       all_cos=None, all_fail_events=None):
    """ Generate a sprov model using information from supervisor
    """
    dso = supervisor.supervisorConfigDso(dsoname=ring_name)
    dso_params = dict(dso['params'])
    hardware = supervisor.supervisorShowHardware()

    # If not `all_cos` retrieve it from supervisor config
    if not all_cos:
        all_cos = dso_params['provcoslist'].split(',')

    # If not `all_fail_events` retrieve it from supervisor config
    if not all_fail_events:

        def parse_failevent(fail_event):
            """ Convert "A=1" into {"A": 1} """
            name, value = fail_event.split('=', 1)
            return {name: int(value)}

        # Note: In the supervisor `provfaileventlist` is only a flat list of
        # simple event (e.g.: [{'server': 2}, {'site': 1}, {'server': 1}]).
        # Normally the event list should be a list of multiple events
        # e.g.: [{'server': 1, 'site': 1}, {'server': 2}]
        try:
            all_fail_events = [
                parse_failevent(failevent)
                for failevent in dso_params['provfaileventlist'].split(',')
            ]
        except (KeyError, ValueError):
            pass

    # Get all servers in zones
    zones = {}
    for zone in hardware.get('zones', []):
        if int(zone['stats']['nb_nodes_total']):
            zones[zone['name']] = []
            for agent in zone.get('agents', []):
                try:
                    if int(agent['stats']['nb_nodes_total']):
                        zones[zone['name']].append(agent['node']['ipstr'])
                except KeyError:
                    continue

    # Groups nodes by servers (using address)
    node_grouped = {}
    for node in sorted(dso['nodes'], key=lambda node: node['addr']):
        node_grouped.setdefault(node['addr'].split(':')[0], []).append(node)

    servers = {}
    for addr, list_nodes in node_grouped.items():
        # First: check diskgroups
        # for each node, take the list of all disks (sorted)
        # convert it into a tuple
        # use set() on all those sorted tuple to remove exact duplicates
        disk_sets = set(tuple(sorted(node['disks'])) for node in list_nodes)
        seen = set()
        dup_disks = set()
        for disk_list in disk_sets:
            for disk in disk_list:
                if disk in seen:
                    dup_disks.add(disk)
                seen.add(disk)
        if dup_disks:
            raise ValueError('server {0} has mixed diskgroup'.format(addr))

        # Second: create sprov objects
        if len(disk_sets) > 1:
            server = Server.create(nb_disk_groups=len(disk_sets))
            server.setName(addr)
            server.children = []
            for num, diskgroup in enumerate(disk_sets):
                # Get all processes in this diskgroup
                processes = [
                    node for node in list_nodes
                    if tuple(sorted(node['disks'])) == diskgroup
                ]
                diskgroup = DiskGroup(nb_processes=len(processes))
                diskgroup.setName('Diskgroup{0}'.format(num))
                diskgroup.setCapacity(
                    '{0}MB'.format(
                        processes[0]['stats']['disk']['capacity']['total']
                    )
                )
                for i, node in enumerate(processes):
                    try:
                        diskgroup.addNode(Node(i, node['key']))
                    except Exception:
                        pass
                server.addChildComponent(diskgroup)
        else:
            server = Server.create(nb_processes=len(list_nodes))
            server.setName(addr)
            server.setCapacity(
                '{0}MB'.format(
                    list_nodes[0]['stats']['disk']['capacity']['total']
                )
            )
            for i, node in enumerate(list_nodes):
                try:
                    server.addNode(Node(i, node['key']))
                except Exception:
                    pass
        servers[addr] = server

    # Create sprov Ring object
    ring = Ring()

    # Create sprov Site objects and add it to the Ring object if needed
    if len(list(zones.keys())) > 1:
        for zone in zones:
            site = Site()
            site.setName(zone)
            for server in zones[zone]:
                if server in servers:
                    if servers[server].getTotalCapacity():
                        site.addChildComponent(servers[server])
            if site.getTotalCapacity():
                ring.addChildComponent(site)
    else:
        for _, server in servers.items():
            if server.getTotalCapacity():
                ring.addChildComponent(server)

    # Set ClassOfServer for Ring object
    ring.setClassesOfService([ClassOfService(cos) for cos in all_cos])

    # Set FailureEventList for Ring object
    ring.events = FailureEventSet()
    for fail_event in all_fail_events:
        ring.events.addFailureEvent(
            FailureSet(**fail_event),
            [ClassOfService(cos) for cos in all_cos]
        )
    ring.updateEvents()

    return ring
