# -*- coding: utf-8 -*-

from pkgutil import extend_path


__path__ = extend_path(__path__, __name__)

__version__ = "1.0"
__revision__ = ""
